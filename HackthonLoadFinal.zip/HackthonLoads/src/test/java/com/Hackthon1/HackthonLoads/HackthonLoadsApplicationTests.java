package com.Hackthon1.HackthonLoads;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackthonLoadsApplicationTests {

	@Test
	void contextLoads() {
	}

}
