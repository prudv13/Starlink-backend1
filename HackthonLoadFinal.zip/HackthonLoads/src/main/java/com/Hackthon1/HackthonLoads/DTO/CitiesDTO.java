package com.Hackthon1.HackthonLoads.DTO;

import lombok.Data;

@Data
public class CitiesDTO {
    String City;
}
