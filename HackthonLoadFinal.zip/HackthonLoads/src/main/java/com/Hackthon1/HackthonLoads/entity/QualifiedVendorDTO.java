package com.Hackthon1.HackthonLoads.entity;

public interface QualifiedVendorDTO {

    public String getLocation();

    public Integer getVendorId();

}
