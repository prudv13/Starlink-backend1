package com.Hackthon1.HackthonLoads.DTO;

import lombok.Data;

@Data
public class LoadPostDTO {

    private String origin;

    private String destination;

    private String startDate;

    private String capacity;

    private String transportType;

}
