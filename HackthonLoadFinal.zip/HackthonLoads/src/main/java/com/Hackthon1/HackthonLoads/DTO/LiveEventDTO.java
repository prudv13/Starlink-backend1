package com.Hackthon1.HackthonLoads.DTO;

import lombok.Data;

@Data
public class LiveEventDTO {


    Integer originId;

    Integer destinationId;

    Float totalWeight;

}
