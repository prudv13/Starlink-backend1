package com.Hackthon1.HackthonLoads;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackthonLoadsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackthonLoadsApplication.class, args);
	}

}
